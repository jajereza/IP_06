﻿using System;

class Program
{
     static void Main(string[] args)
    {
        Console.WriteLine("Julio Jerez - 1148723");
        Console.WriteLine("Ingrese un numero entre 0 y 999.99:");
        Console.WriteLine("");

        double cantidad = double.Parse(Console.ReadLine());
        Console.WriteLine("");

        if (cantidad >= 0 && cantidad <= 999.99)
        {
            int centavos = (int)(cantidad * 100);

            int billetes100 = centavos / (100 * 100);
            centavos %= 100 * 100;

            int billetes50 = centavos / (50 * 100);
            centavos %= 50 * 100;

            int billetes20 = centavos / (20 * 100);
            centavos %= 20 * 100;

            int billetes10 = centavos / (10 * 100);
            centavos %= 10 * 100;

            int billetes5 = centavos / (5 * 100);
            centavos %= 5 * 100;

            int monedas1 = centavos / 100;
            centavos %= 100;

            int monedas25 = centavos / 25;
            centavos %= 25;

            int monedas1Centavo = centavos;

            Console.WriteLine("Equivalencia en billetes y monedas:");
            Console.WriteLine("");
            Console.WriteLine("Billetes de 100 quetzales: " + billetes100);
            Console.WriteLine("Billetes de 50 quetzales: " + billetes50);
            Console.WriteLine("Billetes de 20 quetzales: " + billetes20);
            Console.WriteLine("Billetes de 10 quetzales: " + billetes10);
            Console.WriteLine("Billetes de 5 quetzales: " + billetes5);
            Console.WriteLine("Monedas de 1 quetzal: " + monedas1);
            Console.WriteLine("Monedas de 25 centavos: " + monedas25);
            Console.WriteLine("Monedas de 1 centavo: " + monedas1Centavo);
        }
        else
        {
            Console.WriteLine("");
            Console.WriteLine("Error: La cantidad debe estar entre 0 y 999.99 quetzales.");
        }
        Console.WriteLine("");
        Console.WriteLine("Presione cualquier tecla para salir");
        Console.ReadKey();
    }
}
