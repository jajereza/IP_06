﻿
class Clase_Menu
{
    static void Main(string[] args) 
    {
        Console.WriteLine("Mi programa, Control de calidad en la Industria de Teléfonos");
        Console.WriteLine();
        Console.WriteLine("Seleccione un tipo de control");
        Console.WriteLine();
        Console.WriteLine("Menú Principal");
        Console.WriteLine("1. Control de Calidad");
        Console.WriteLine("2. Cuellos de Botella");
        Console.WriteLine("3. Tipo de Teléfono");
        Console.WriteLine("4. Material Disponible");

        string opcion;
        opcion = Console.ReadLine();


        switch (opcion)
        {
            case "1":
                Console.WriteLine("Usted seleccionó: " + opcion + " " + "Control de Calidad");
                break;
            case "2":
                Console.WriteLine("Usted seleccionó: " + opcion + " " + "Cuellos de Botella");
                break;
            case "3": 
                Console.WriteLine("Usted seleccionó: " + opcion + " " + "Tipo de Teléfono");
                break;
            case "4":
                Console.WriteLine("Usted seleccionó: " + opcion + " " + "Material Disponible");
                break;
            default:
                Console.WriteLine("Seleccione una opción válida");
                break;
        }

        Console.ReadKey(); 
    }
}