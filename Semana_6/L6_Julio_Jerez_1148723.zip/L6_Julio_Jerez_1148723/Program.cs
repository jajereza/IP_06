﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1: Operaciones aritméticas");
        double sNumero1;
        double sNumero2;

        Console.WriteLine("Ingrese Número 1");
        sNumero1 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese Número 2");
        sNumero2 = double.Parse(Console.ReadLine());
        Console.ReadKey();

        double sSuma = sNumero1 + sNumero2; 
        double sResta = sNumero1 - sNumero2;    
        double sMultiplicacion = sNumero1 * sNumero2;   
        double sDivision = sNumero1 / sNumero2;
        double sDiv = (int)sNumero1 / sNumero2;
        double smod = sNumero1 % sNumero2;

        Console.WriteLine("El resultado de la suma entre " + sNumero1 + " y " + sNumero2 + " es: " + sSuma);
        Console.WriteLine("El resultado de la resta entre " + sNumero1 + " y " + sNumero2 + " es: " + sResta);
        Console.WriteLine("El resultado de la multiplicación entre " + sNumero1 + " y " + sNumero2 + " es: " + sMultiplicacion);
        Console.WriteLine("El resultado de la división entre " + sNumero1 + " y " + sNumero2 + " es: " + sDivision);
        Console.WriteLine("El resultado del div entre " + sNumero1 + " y " + sNumero2 + " es: " + sDiv);
        Console.WriteLine("El resultado del mod entre " + sNumero1 + " y " + sNumero2 + " es: " + smod);

        Console.ReadKey();
        Console.Clear();

        Console.WriteLine("Ejercicio 2: Operaciones booleanas");

        bool sMayor;
        bool sMenor;
        bool sIgual;

        sMayor = sNumero1 > sNumero2;
        Console.WriteLine(sNumero1 + " > " + sNumero2 + " = " + sMayor);
        sMenor = sNumero1 < sNumero2;
        Console.WriteLine(sNumero1 + " < " + sNumero2 + " = " + sMenor);
        sIgual = sNumero1 == sNumero2;
        Console.WriteLine(sNumero1 + " == " + sNumero2 + " = " + sIgual);


        Console.ReadKey();
        Console.Clear();

        Console.WriteLine("Ejercicio 3: Jerarquía de operaciones");
        double sNumero3;
        double sNumero4;
        double sNumero5;
        double a;
        double b;
        double c;
        double i;
        double ii;
        double iii;
        double iv;

        Console.WriteLine("Ingrese Número 1");
        sNumero3 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese Número 2");
        sNumero4 = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese Número 3");
        sNumero5 = double.Parse(Console.ReadLine());

        a=sNumero3;
        b=sNumero4; 
        c=sNumero5;


        i = a * b + c;
        ii = a * (b + c);
        iii = a / b * c;
        iv = ((3 * a) + (2 * b)) / (c * c);
        Console.WriteLine("El resultado entre " + sNumero3 + " * " + sNumero4 + " + " + sNumero5 + " es: " + i);
        Console.WriteLine("El resultado entre " + sNumero3 + " * " + "(" + sNumero4 + " + " + sNumero5 + ")" + " es: " + ii);
        Console.WriteLine("El resultado entre " + sNumero3 + " / " + sNumero4 + " * " + sNumero5 + " es: " + iii);
        Console.WriteLine("El resultado entre " + "(" + sNumero3 + "*3" + ")" + " + " + "(" + sNumero4 + "*2" + ")" + " / " + "(" + sNumero5 + "*" + sNumero5 + ")" + " es: " + iv);


        Console.ReadKey();
        Console.Clear();

        Console.WriteLine("Ejercicio 4: Expresión cuadrática");

        double raiz = (b * b) - (4 * a * c);

        if (raiz > 0)
        {
            double n1 = (-b + Math.Sqrt(raiz))/(2*a);
            double n2 = (-b - Math.Sqrt(raiz)) / (2 * a);
            Console.WriteLine("Las soluciones son x1: " + n1 + " y x2: " + n2);
        }
        else if (raiz == 0){
            double n = -b / 2 * a;
            Console.WriteLine("La única solución es x1: " + n);
        }
        else
        {
            Console.WriteLine("La ecuación no tiene soluciones reales");
        }
        Console.ReadKey();
        Console.Clear();
    }
}