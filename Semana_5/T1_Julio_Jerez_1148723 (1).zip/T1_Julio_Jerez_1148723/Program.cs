﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo Programa");
        string sNombre, sEdad, sCarrera, sCarne;

        Console.WriteLine("Ingrese Nombre");
        sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese Edad");
        sEdad = Console.ReadLine();
        Console.WriteLine("Ingrese Carrera");
        sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese Carné");
        sCarne = Console.ReadLine();

        Console.WriteLine("Nombre: " +  sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carne: " + sCarne);

        Console.WriteLine("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ", mi número de carné es: " + sCarne);
        Console.ReadKey();
    }
}