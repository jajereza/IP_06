﻿class Program
//Inicio clase
{
    static void Main(string[] args) 
    //Inicio método
    {
    Console.WriteLine("Ingrese su nombre");
    string Nombre = Console.ReadLine();
    Console.WriteLine("Hola Mundo!");
    Console.WriteLine("Soy " + Nombre);
    /*
        Esto es un ejemplo de comentarios
        */
    //Otros comentarios
    Console.WriteLine("Hola mundo!");
    Console.WriteLine("Soy " + Nombre);
    Console.ReadKey();
    //Fin método
    }
    //Fin clase
}
