﻿ 
class program
{
    public static double porcentajeDescuento;
    public static double montoCompra;
    public static double CalcularDescuento(double montoCompra)

    {
        double descuento = 0.0;



        if (montoCompra < 400)
        {
            Console.WriteLine("No se aplicó descuento");  
                }
        else
        {
            if (montoCompra <= 1000)
            {
                descuento = montoCompra * 0.07;
                porcentajeDescuento = 7;
            }
            else
            {
                if (montoCompra <= 5000)
                {
                    descuento = montoCompra * 0.10;
                    porcentajeDescuento = 10;
                }
                else
                {
                    if (montoCompra <= 15000)
                    {
                        descuento = montoCompra * 0.15;
                        porcentajeDescuento = 15;
                    }
                    else
                    {
                        descuento = montoCompra * 0.25;
                        porcentajeDescuento = 25;
                    }
                }
            }
        }

        return descuento;
    }

    static void Main()
    {

        Console.WriteLine("Bienvenido a la Tienda El Madrigal");
        Console.WriteLine("");

        Console.WriteLine("Caja de ventas");
        Console.WriteLine("");

        Console.Write("Ingrese el monto de la compra a pagar: ");
        string monto = Console.ReadLine();

        while (!double.TryParse(monto, out montoCompra))
        {
            Console.WriteLine("Ingrese el monto de la compra en el formato correcto, ejemplo: 0.00");
            monto = Console.ReadLine();
        }

        Console.WriteLine("");

        double descuento = CalcularDescuento(montoCompra);

        string codigo = "";
        Console.WriteLine("¿Posee un codigo de descuento? (Si/No)");
        codigo = Console.ReadLine();

        if (codigo == "Si")
        {
            double codigodes = montoCompra * 0.05;
            double porcentajedescuentocodigo = 5;
            double montoFinal = montoCompra - descuento - codigodes;
            double descuentofin = porcentajeDescuento + porcentajedescuentocodigo;
            Console.WriteLine("");
            Console.WriteLine("Se le aplicó un descuento del " + descuentofin + "%, Su monto a pagar es de: " + montoFinal);
        }

        else if (codigo == "No")
        {
            double montoFinal = montoCompra - descuento;
            Console.WriteLine("");
            Console.WriteLine("Se le aplicó un descuento del " + porcentajeDescuento + "%, Su monto final a pagar es de: " + montoFinal);
        }

        Console.ReadKey();
    }

}
