﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string OpcionMenu;
        do
        {
            Console.WriteLine("Control de Calidad en la Industria de Teléfonos");
            Console.WriteLine("");
            Console.WriteLine("Este programa permite seleccionar el problema a controlar: Control de Calidad, cuellos de botella, Tipos de Teléfonos y material Disponible");
            Console.WriteLine("");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Seleccione una opción");
            Console.WriteLine("");
            Console.WriteLine("1. Control de Calidad en la Industria de Teléfonos");
            Console.WriteLine("2. Manual de Usuario");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");

            Console.WriteLine("");
            OpcionMenu = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("");
            switch (OpcionMenu)
            {
                case "1. Control de Calidad en la Industria de Teléfonos":
                    Console.Clear();
                    Console.WriteLine("Control de Calidad en La Industria de Teléfonos");
                    Console.WriteLine("");
                    Console.WriteLine("Por favor, Seleccione el tipo de Control de Calidad que desea evaluar");
                    Console.WriteLine("");

                    Console.WriteLine("1. Control de Calidad");
                    Console.WriteLine("2. Cuellos de Botella");
                    Console.WriteLine("3. Tipo de Teléfono");
                    Console.WriteLine("4. Material Disponible");
                    string OpcionControlCalidad;
                    OpcionControlCalidad = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine("");

                    switch (OpcionControlCalidad)
                    {
                        case "1. Control de Calidad":
                            Console.Clear();
                            Console.WriteLine("Usted seleccionó la Opción No " + OpcionControlCalidad);
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("Máquina 1: Inserción de componentes. Esta máquina se utiliza para insertar componentes electrónicos en las placas de circuito impreso, como resistencias, transistores y chips.");
                            Console.WriteLine("ESTADO: Buen funcionamiento");
                            Console.WriteLine("");
                            Console.WriteLine("Máquina 2: Prueba y calidad. Esta máquina realiza pruebas de calidad y funcionamiento en los teléfonos ensamblados, incluyendo pruebas de pantalla táctil, cámaras, sensores, conectividad, batería, etc.");
                            Console.WriteLine("ESTADO: Mantenimiento");
                            Console.WriteLine("");
                            Console.WriteLine("Máquina 3: Montaje de baterías. Esta máquina ensambla y suelda las batería en su lugar.");
                            Console.WriteLine("ESTADO: Fuera de Servicio");
                            Console.WriteLine("");
                            Console.WriteLine("Máquina 4: Máquina de embalaje y etiquetado. Su función es empaquetar los teléfonos en cajas y aplicar etiquetas de información.");
                            Console.WriteLine("ESTADO: Mantenimiento");
                            Console.WriteLine("");
                            Console.WriteLine("Máquina 5: Máquina de grabado láser. Se utiliza para realizar los grabados en la carcasa del teléfono, como logotipos o información de marca.");
                            Console.WriteLine("ESTADO: Buen funcionamiento");
                            Console.WriteLine("");
                            Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                            break;
                        case "2. Cuellos de Botella":
                            Console.Clear();
                            Console.WriteLine("Usted seleccionó la Opción No " + OpcionControlCalidad);
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("Cuello de Botella 1: Máquinas de ensamblaje lentas. Si una máquina clave en la línea de ensamblaje, como la que inserta componentes en la placa de circuito, opera lentamente, se creará un cuello de botella");
                            Console.WriteLine("");
                            Console.WriteLine("Solución: Si una máquina específica es un cuello de botella, se debe considerar en invertir en equipos más rápidos y eficientes. Además se pueden implementar tecnologías de mejora de procesos para aumentar su rendimiento.");
                            Console.WriteLine("");
                            Console.WriteLine("Cuello de Botella 2: Transporte ineficiente. Si el transporte de componentes o teléfonos entre máquinas no se realiza de manera eficiente, puede crear demoras en el proceso.");
                            Console.WriteLine("");
                            Console.WriteLine("Solución: Implementar un sistema de seguimiento de la producción que permita supervisar el rendimiento en tiempo real y detectar cuellos de botella antes de que afecten significativamente la producción.");
                            Console.WriteLine("");
                            Console.WriteLine("Cuello de Botella 3: Falta de suministros. Si hay una falta de componentes o materiales necesarios para la producción, como baterías, pantallas o placas de circuito, se puede generar un cuello de botella.");
                            Console.WriteLine("");   
                            Console.WriteLine("Solución: Asegurarse de que siempre haya suficientes componentes y materiales disponibles para mantener la producción sin interrupciones. Usar sistemas de gestión de inventario para prevenir escasez o exceso de inventario.");
                            Console.WriteLine("");
                            Console.WriteLine("Cuello de Botella 4: Problemas de ajuste y configuración. Cambiar la configuración de las máquinas para adaptarse a diferentes modelos de teléfonos puede llevar tiempo y provocar cuellos de botella si no se realiza de manera eficaz.");
                            Console.WriteLine("");
                            Console.WriteLine("Solución:  Asegurarse de que el diseño de los teléfonos y sus componentes sean compatible con los procesos de fabricación. Fabricar un solo modelo de teléfono a la vez reducirá los cuellos de botella.");
                            Console.WriteLine("");
                            Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                            break;
                        case "3. Tipo de Teléfono":
                            Console.Clear();
                            Console.WriteLine("Usted seleccionó la Opción No " + OpcionControlCalidad);
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("Tipo de Teléfonos en Fabricación");
                            Console.WriteLine("");
                            Console.WriteLine("1. Galaxy S23 Ultra : El teléfono insignia de Samsung, con una pantalla AMOLED de 6,8 pulgadas, un procesador Snapdragon 8 Gen 2, una batería de 5000 mAh y una cámara principal de 200 megapíxeles.");
                            Console.WriteLine("");
                            Console.WriteLine("2. Galaxy S23 : Un teléfono de gama alta con una pantalla AMOLED de 6,1 pulgadas, un procesador Snapdragon 8 Gen 2 y una cámara principal de 50 megapíxeles.");
                            Console.WriteLine("");
                            Console.WriteLine("3. Galaxy Z Fold 5 : Un teléfono plegable con una pantalla interna de 7,6 pulgadas y una pantalla externa de 6,1 pulgadas. Tiene un procesador Snapdragon 8 Gen 2 y una batería de 4400 mAh.");
                            Console.WriteLine("");
                            Console.WriteLine("4. Galaxy Z Flip 5 : Un teléfono plegable con una pantalla interna de 6,7 pulgadas. Tiene un procesador Snapdragon 8 Gen 2 y una batería de 3700 mAh.");
                            Console.WriteLine("");
                            Console.WriteLine("5. Galaxy A54 5G : Un teléfono de gama media con una pantalla AMOLED de 6,5 pulgadas, un procesador Snapdragon 778G y una cámara principal de 64 megapíxeles.");
                            Console.WriteLine("");
                            Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                            break;
                        case "4. Material Disponible":
                            Console.Clear();
                            Console.WriteLine("Usted seleccionó la Opción No " + OpcionControlCalidad);
                            Console.WriteLine("");
                            Console.WriteLine("");
                            Console.WriteLine("Material Disponible en Bodega");
                            Console.WriteLine("");
                            Console.WriteLine("1. 24000 Unidades de Procesadores");
                            Console.WriteLine("");
                            Console.WriteLine("2. 9000 Unidades de Memoria RAM");
                            Console.WriteLine("");
                            Console.WriteLine("3. 35000 Unidades de Baterías");
                            Console.WriteLine("");
                            Console.WriteLine("4. 10000 Unidades de Pantallas");
                            Console.WriteLine("");
                            Console.WriteLine("5. 40000 Unidades de Cámaras");
                            Console.WriteLine("");
                            Console.WriteLine("6. 89760 Unidades de Carcasas");
                            Console.WriteLine("");
                            Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                            break;
                        default:
                            Console.Clear();
                            Console.WriteLine("Usted seleccionó una opción inválida. Por favor, seleccione una opción correcta en el siguiente formato: 1. Control de Calidad");
                            Console.WriteLine("");
                            Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                            break;
                    }
                    break;
                case "2. Manual de Usuario":
                    Console.Clear();
                    Console.WriteLine("Manual de Usuario");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("1. Procesos del Programa");
                    Console.WriteLine("");
                    Console.WriteLine("El programa no posee cálculos, el proceso que realiza es identificar la opción seleccionada en el menú y mostrar la información detallada sobre cada problemática. ");
                    Console.WriteLine("");
                    Console.WriteLine("2. Pasos a Seguir");
                    Console.WriteLine("");
                    Console.WriteLine("a. Mensajes Informativos sobre el Menú Principal: El programa muestra mensajes informativos que describen las opciones disponibles en el menú principal, como \"Control de Calidad en la Industria de Teléfonos,\" \"Manual de Usuario,\" \"Créditos\" y \"Salir.\" Estos mensajes informan al usuario sobre las funciones disponibles y ayudan a guiar su elección.");
                    Console.WriteLine("");
                    Console.WriteLine("b. Mensajes de Selección de Opciones: Cuando el usuario selecciona una opción del menú principal y la confirma, el programa muestra mensajes relacionados con la opción elegida");
                    Console.WriteLine("");
                    Console.WriteLine("c. Descripciones de Procesos Seleccionados: Después de que el usuario selecciona una de las opciones del segundo Menú, el programa muestra una descripción del proceso relacionado con esa selección específica. Estas descripciones detallan lo que implica el proceso y brindan información sobre la planta.");
                    Console.WriteLine("");
                    Console.WriteLine("d. Mensaje de Salida: Cuando el usuario selecciona \"4. Salir\" en el menú principal, el programa muestra un mensaje de despedida, indicando que el programa está finalizando. Este mensaje informa al usuario que la aplicación se cerrará.");
                    Console.WriteLine("");
                    Console.WriteLine("3. Propósito del Programa");
                    Console.WriteLine("");
                    Console.WriteLine("El tema principal de este proyecto fue la mejora de la producción y la eficiencia en las fábricas de teléfonos, que es un proceso muy complejo donde la calidad y la gestión de recursos son cruciales. Teniendo esto en cuenta, identificamos cuatro aspectos que son necesarios para mejorar la eficiencia de la producción.");
                    Console.WriteLine("");
                    Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                    break;
                case "3. Créditos":
                    Console.Clear();
                    Console.WriteLine("Créditos");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Nombre del Proyecto:");
                    Console.WriteLine("");
                    Console.WriteLine("El control de Calidad en la Industria de Teléfonos.");
                    Console.WriteLine("");
                    Console.WriteLine("Fecha de Creación:");
                    Console.WriteLine("");
                    Console.WriteLine("23 de Octubre del 2023.");
                    Console.WriteLine("");
                    Console.WriteLine("Estimado de Horas dedicadas:");
                    Console.WriteLine("");
                    Console.WriteLine("5 horas.");
                    Console.WriteLine("");
                    Console.WriteLine("Creado por:");
                    Console.WriteLine("");
                    Console.WriteLine("Julio Adolfo Jerez Aquino & Edwin Daniel Chaclán Barrios");
                    Console.WriteLine("");
                    Console.WriteLine("Números de Carnés");
                    Console.WriteLine("");
                    Console.WriteLine("1148723 - 1068623");
                    Console.WriteLine("");
                    Console.WriteLine("Carrera:");
                    Console.WriteLine("");
                    Console.WriteLine("Ingeniería Industrial");
                    Console.WriteLine("");
                    Console.WriteLine("Para regresar al Inicio presione la tecla: ENTER");
                    break;
                case "4. Salir":
                    Console.Clear();
                    Console.WriteLine("Saliendo del programa... Muchas gracias por su visita :D");
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Usted seleccionó una opción inválida. Por favor, seleccione una opción correcta en el siguiente formato: 1. Control de Calidad en la Industria de Teléfonos");
                    Console.WriteLine("");
                    Console.WriteLine("Para regresar el Inicio presione la tecla: ENTER");
                    break;
            }
            Console.ReadKey();
            Console.Clear();
        } while (OpcionMenu != "4. Salir");
    }
}