﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1");
        int sNumero1;

        Console.WriteLine("Ingrese Número 1");
        sNumero1 = Int32.Parse(Console.ReadLine());
        Console.ReadKey();
        if (sNumero1 > 0)
        {
            Console.WriteLine("El número ingresado es positivo");
        }
        else if (sNumero1 == 0) {
            Console.WriteLine("El número ingresado es 0");
        }
        else if (sNumero1 < 0)
        {
            Console.WriteLine("El número ingresado es negativo");
        }
        else
        {

        }
        Console.ReadKey();
        Console.Clear();

        Console.WriteLine("Ejercicio 2");

        Console.ReadKey();
        Console.WriteLine("Seleccione una opción");
        Console.WriteLine("");
        Console.WriteLine("1. Lunes");
        Console.WriteLine("2. Martes");
        Console.WriteLine("3. Miércoles");
        Console.WriteLine("4. Jueves");
        Console.WriteLine("5. Viernes");
        Console.WriteLine("6. Sábado");
        Console.WriteLine("7. Domingo");

        string opcion;
        opcion = Console.ReadLine();
        Console.WriteLine();
        switch(opcion)
        {
            case "1":
                Console.WriteLine("El día es Lunes");
                break;
            case "2":
                Console.WriteLine("El día es Martes");
                break;
            case "3":
                Console.WriteLine("El día es Miércoles");
                break;
            case "4":
                Console.WriteLine("El día es Jueves");
                break;
            case "5":
                Console.WriteLine("El día es Viernes");
                break;
            case "6":
                Console.WriteLine("El día es Sábado");
                break;
            case "7":
                Console.WriteLine("El día es Domingo");
                break;
            default:
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                break;
        }
        Console.ReadKey();      
    }
}
